<?php
/**
 * @package     Joomla.Site
 * @subpackage  Templates.coopceptor - Material Kit free
 * original webdesigner: Material TIM
 * @copyright   Copyright (C) 2016 Alexon Balangue. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */


defined('_JEXEC') or die;
$apps             = JFactory::getApplication();
$docs             = JFactory::getDocument();
$users            = JFactory::getUser();
$browser = JBrowser::getInstance();
$this->language  = $docs->language;
$this->direction = $docs->direction;

// Getting params from template
$params = $apps->getTemplate(true)->params;

$sitename = $apps->get('sitename');
$desc_site = $apps->getCfg('MetaDesc');
//PARAMS
$Grps_html = $this->params->get('groups-html');
$hide_joomla_default = $this->params->get('Pages-js-default');
// Output as HTML5
$docs->setHtml5(true);
$option   = $apps->input->getCmd('option', '');
$view     = $apps->input->getCmd('view', '');
$layout   = $apps->input->getCmd('layout', '');
$task     = $apps->input->getCmd('task', '');
$itemid   = $apps->input->getCmd('Itemid', '');

if($task == "edit" || $layout == "form" ){ $fullWidth = 1; } else { $fullWidth = 0; }
//Remove défault JS Joomla 3.3.6/+ on front end home pages or other component

$docs->addStyleSheetVersion($this->baseurl .'templates/' . $this->template . '/assets/css/custom.min.css');

		
switch($hide_joomla_default):
	case 'home':
		$this->_script = $this->_scripts = array();	
		unset($docs->_scripts[JURI::root(true) . '/media/system/js/mootools-more.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/system/js/mootools-core.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/system/js/core.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/system/js/modal.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/system/js/caption.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/jui/js/jquery.min.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/jui/js/jquery-migrate.min.js']);
		unset($docs->_scripts[JURI::root(true) . '/media/jui/js/jquery-noconflict.js']);
		JHtmlBootstrap::framework(false);
		unset($docs->_scripts[JURI::root(true) . '/media/jui/js/bootstrap.min.js']);
	break;
	case 'component':
		//foreach ($this->_scripts as $script => $value){ if (preg_match('/media\/jui/i', $script)){ unset($this->_scripts[$script]); } }	
		JHtmlBootstrap::framework(false);
	break;
	default:
		$docs->addScriptVersion($this->baseurl . '/templates/' . $this->template . '/assets/template.js');
		// Add Stylesheets
		$docs->addStyleSheetVersion($this->baseurl . '/templates/' . $this->template . '/assets/template.css');
		// Check for a custom CSS file
		$userCss = JPATH_SITE . '/templates/' . $this->template . '/assets/user.css';
		if (file_exists($userCss) && filesize($userCss) > 0)
		{
			$docs->addStyleSheetVersion('templates/' . $this->template . '/assets/user.css');
		}
			break;
endswitch;

# Adjusting content width

if ($this->countModules('sidebar-right')){
	$body_sizes = "col-md-8";
	$right_sizes = "col-md-3";
} else {
	$body_sizes = "col-md-12";
	$right_sizes = "hidden-xs hidden-sm hidden-md hidden-lg";
}
// Logo file or site title param logoFile

if(!empty($this->params->get('logoFile'))){
	$mypersonal_photo = $this->baseurl.'/'.$this->params->get('logoFile');
} else {
	$mypersonal_photo = $this->baseurl.'/templates/'.$this->template.'/assets/images/logo.png';
}

$Params_grpsJs = $this->params->get('groups-method');
$Params_grpsCSS = $this->params->get('groups-method');
if ($Params_grpsJs == 'production') : 
	$docs->addStyleSheetVersion(JUri::root(true).'/templates/'.$this->template.'/assets/css/material-kit.min.css');
elseif ($Params_grpsJs == 'custom') : 
	$docs->addStyleSheetVersion(JUri::root(true).'/templates/'.$this->template.'/assets/css/material-kit.css');
endif;


$docs->addStyleSheet('https://fonts.googleapis.com/icon?family=Material+Icons');
$docs->addStyleSheet('https://fonts.googleapis.com/css?family=Roboto:300,400,500,700');


require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'html'.DIRECTORY_SEPARATOR.'renderer'.DIRECTORY_SEPARATOR.'head.php';

if( $browser->isMobile() == true ){
  $JMobileDetectHeader = '<jdoc:include type="modules" name="banner-mheader" style="nones" />';
  $JMobileDetectFooter = '<jdoc:include type="modules" name="banner-mfooter" style="nones" />';
  $JMobileDetectSidebar = '<jdoc:include type="modules" name="banner-msidebar" style="nones" />';
} else {
  $JMobileDetectHeader =  '<jdoc:include type="modules" name="banner-header" style="nones" />';
  $JMobileDetectFooter = '<jdoc:include type="modules" name="banner-footer" style="nones" />';
  $JMobileDetectSidebar = '<jdoc:include type="modules" name="banner-sidebar" style="nones" />';
}

$headshows = $this->params->get('headshow');

?>
[doctype html="html" /]
<html <?php echo $params->get('ampHTML'); ?> lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	[head]
	<jdoc:include type="head" />
	[/head]
	[begins tags="body" class="landing-page" mdatatype="http://schema.org/WebPage" /]
    <nav class="navbar navbar-transparent navbar-fixed-top navbar-color-on-scroll">
    	<div class="container">
        	<div class="navbar-header">
        		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-dyiprod">
            		<span class="sr-only">Menu</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
        		</button>
        		<a href="<?php echo $this->baseurl; ?>">
				   <div class="logo-container">
						<div class="logo">
							<img src="<?php echo $mypersonal_photo; ?>" alt="<?php echo $sitename; ?>">
						</div>
						<div class="brand sr-only">
							<?php echo $sitename; ?>
						</div>
					</div>
					<div class="ripple-container"></div>
				</a>
				<meta itemprop="image" content="<?php echo $mypersonal_photo; ?>">
        	</div>

        	
			<?php if ($this->countModules('materialkit_menu')) : ?>
        	<div class="collapse navbar-collapse" id="navigation-dyiprod">
        		<jdoc:include type="modules" name="materialkit_menu" style="nones" />
        	</div>
			<?php endif; ?>
    	</div>
    </nav>	
	<div class="wrapper">
		<?php switch($Grps_html): case 'boostrap3-home': ?>
		<?php if ($this->countModules('information')) : ?>
        <div class="header header-filter" style="background-image: url('assets/images/bg-full.jpg');">
            <div class="container">
                <div class="row">
				 <jdoc:include type="modules" name="information" style="none" />
                </div>
            </div>
        </div>
		<?php endif; ?>
		
		<?php if ($this->countModules('ideas')) : ?>
		<div class="main main-raised main-bg-yellow">
			<div class="container">
		    	<div class="section text-center section-landing">
	                <div class="row">
	                    <jdoc:include type="modules" name="ideas" style="none" />
	                </div>
	            </div>
			</div>
		</div>
		<?php endif; ?>
		<?php if ($this->countModules('mooc')) : ?>
		<div class="main main-bg-bleu">
			<div class="container">
	        	<div class="section text-center">
					<div class="row">
						<jdoc:include type="modules" name="mooc" style="none" />
					</div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>
		<?php if ($this->countModules('security')) : ?>
		<div class="main">
			<div class="container">
		    	<div class="section text-center section-landing">
					<div class="features">
						<div class="row">
						<jdoc:include type="modules" name="security" style="none" />
		                </div>
					</div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>
		
		<?php if ($this->countModules('event')) : ?>
		<div class="main main-bg-bleu">
			<div class="container">
	        	<div class="section text-center">
					<div class="row">
						<jdoc:include type="modules" name="event" style="none" />
					</div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>

		<?php if ($this->countModules('shop')) : ?>
		<div class="main">
			<div class="container">
	        	<div class="section landing-section">
	                <div class="row">
						<jdoc:include type="modules" name="shop" style="none" />
	                </div>
	            </div>
	        </div>
		</div>
		<?php endif; ?>
		<?php if ($this->countModules('payment')) : ?>
		<div class="main main-bg-bleu">
			<div class="container">
	        	<div class="section text-center">
					<div class="row">
						<jdoc:include type="modules" name="payment" style="none" />
					</div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>

		
		<div class="main">
			<div class="container">
	        	<div class="section landing-section">
	                <div class="row">
						<div class="col-md-6">
							<jdoc:include type="modules" name="login" style="none" />
						</div>
						<div class="col-md-6">
							<jdoc:include type="modules" name="register" style="none" />
						</div>
	                </div>
	            </div>
	        </div>
		</div>
		
		<?php if ($this->countModules('local')) : ?>
		<div class="main main-bg-bleu">
			<div class="container">
	        	<div class="section text-center">
					<div class="row">
						<jdoc:include type="modules" name="local" style="none" />
					</div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>

		<?php if ($this->countModules('team')) : ?>
		<div class="main main-raised main-bg-yellow">
			<div class="container">
	        	<div class="section text-center">
					<jdoc:include type="modules" name="team" style="none" />
	            </div>
	        </div>
	    </div>
		<?php endif; ?>		
		<?php break; case 'boostrap3-component': ?>

        <div class="header header-filter" style="background-image: url('assets/images/bg-full.jpg');">
            <div class="container">
                <div class="row">
					<div class="col-md-7">
						<h1 class="title"><?php echo $docs->getTitle(); ?></h1>
	                    <h4><?php echo $desc_site; ?></h4>
					</div>
					<div class="col-md-5">
						<h3>Prochainement en direct!</h3>
						<p><a href="#" class="btn btn-primary btn-raised btn-lg">
							<i class="fa fa-play"></i> Chaîne TV
						</a><br>
						<a href="#" class="btn btn-primary btn-raised btn-lg">
							<i class="fa fa-play"></i> Chaîne Radio
						</a><p>
					</div>
                </div>
            </div>
        </div>

		<div class="main main-raised main-bg-yellow">
			<div class="container">
		    	<div class="section text-center section-landing">
	                <div class="row">
	                    <div class="col-md-12">
							<?php echo $JMobileDetectHeader; ?>
	                    </div>
	                </div>
	            </div>
			</div>
		</div>

		<div class="main">
			<div class="container">
	        	<div class="section text-center"> 
					[begins tags="div" class="row" /]
						[begins tags="div" class="<?php echo $body_sizes; ?>" /]
							<jdoc:include type="message" />
							<jdoc:include type="component" />
						[ends tags="div" /] 
						[begins tags="div" class="<?php echo $right_sizes; ?>" /]
							<jdoc:include type="modules" name="sidebar-right" style="nones" />
							<?php echo $JMobileDetectSidebar; ?>
						[ends tags="div" /] 
					[ends tags="div" /] 
	            </div>
	        </div>
	    </div>
		<?php if ($this->countModules('breadcrumb')) : ?>
		<div class="main main-bg-bleu">
			<div class="container">
	        	<div class="section text-center">
					[begins tags="div" class="row" /]
						[begins tags="div" class="col-md-6" /]
							<h2 class="title-color"><?php echo $sitename; ?></h2>
						[ends tags="div" /] 
						[begins tags="div" class="col-md-6" /]
							<jdoc:include type="modules" name="breadcrumb" style="nones" />
						[ends tags="div" /] 
					[ends tags="div" /] 
	            </div>
	        </div>
	    </div>
		<?php endif; ?>

		<div class="main">
			<div class="container">
	        	<div class="section landing-section">
	                <div class="row">
						<div class="col-md-6">
							<jdoc:include type="modules" name="login" style="none" />
						</div>
						<div class="col-md-6">
							<jdoc:include type="modules" name="register" style="none" />
						</div>
	                </div>
	            </div>
	        </div>
		</div>

		<div class="main main-raised main-bg-yellow">
			<div class="container">
	        	<div class="section text-center">
						<div class="row">
			                <div class="col-md-12">
							<?php echo $JMobileDetectFooter; ?>
			                </div>
						</div>
	            </div>
	        </div>
	    </div>
			
		<?php break; case 'boostrap4-home': ?>

		<?php break; case 'boostrap4-component': ?>
			
		<?php break; case 'offline': ?>
       <div class="header header-filter" style="background-image: url('assets/images/bg-full.jpg');">
            <div class="container">
                <div class="row">
					<div class="col-md-7">
						<h1 class="title"><?php echo $docs->getTitle(); ?></h1>
	                    <h4><?php echo $desc_site; ?></h4>
					</div>
					<div class="col-md-5">
						<h3>Prochainement en direct!</h3>
						<p><a href="#" class="btn btn-primary btn-raised btn-lg">
							<i class="fa fa-play"></i> Chaîne TV
						</a><br>
						<a href="#" class="btn btn-primary btn-raised btn-lg">
							<i class="fa fa-play"></i> Chaîne Radio
						</a><p>
					</div>
                </div>
            </div>
        </div>

		<div class="main main-raised main-bg-yellow">
			<div class="container">
		    	<div class="section text-center section-landing">
	                <div class="row">
	                    <div class="col-md-12"><h4 class="modal-title">Sorry, Member team login only</h4>
	                    </div>
	                </div>
	            </div>
			</div>
		</div>	
		<div class="main main-raised">
			<div class="container">
		    	<div class="section text-center section-landing">
	                <div class="row">
	                    <div class="col-md-12">
						[begins tags='form' more='action="<?php echo JRoute::_('index.php', true); ?>" method="post"' /]  
							[begins tags="div" class="form-group" /]  
								[begins tags='label' more='for="username"' /]<?php echo JText::_('JGLOBAL_USERNAME'); ?>[ends tags="label" /]
								[input name="username" id="username" type="text" class="form-control" placeholder="<?php echo JText::_('JGLOBAL_USERNAME'); ?>" /]
							[ends tags="div" /]  
							[begins tags="div" class="form-group" /] 
								[begins tags='label' more='for="passwd"' /]<?php echo JText::_('JGLOBAL_PASSWORD'); ?>[ends tags="label" /]
								[input type="password" name="password" class="form-control" placeholder="<?php echo JText::_('JGLOBAL_PASSWORD'); ?>" id="passwd" /]
							[ends tags="div" /]  
							<?php if (count($twofactormethods) > 1) : ?>
								[begins tags="div" class="form-group" /] 
									[begins tags='label' more='for="secretkey"' /]<?php echo JText::_('JGLOBAL_SECRETKEY'); ?>[ends tags="label" /]
									[input type="text" name="secretkey" class="form-control" placeholder="<?php echo JText::_('JGLOBAL_SECRETKEY'); ?>" id="secretkey" /]
								[ends tags="div" /]  
							<?php endif; ?>
							[input type="submit" name="Submit" class="btn btn-template-main" value="<?php echo JText::_('JLOGIN'); ?>" /]
							[input type="hidden" name="option" value="com_users" /]
							[input type="hidden" name="task" value="user.login" /]
							[input type="hidden" name="return" value="<?php echo base64_encode(JUri::base()); ?>" /]
							<?php echo JHtml::_('form.token'); ?>
						[ends tags="form" /]
	                    </div>
	                </div>
	            </div>
			</div>
		</div>			
		<div class="main main-raised main-bg-yellow">
			<div class="container">
		    	<div class="section text-center section-landing">
	                <div class="row">
	                    <div class="col-md-12">
                        <p class="text-center">
                                <?php if ($apps->get('offline_image') && file_exists($apps->get('offline_image'))) : ?>
							<img width="350" height="200" itemprop="primaryImageOfPage" src="<?php echo $apps->get('offline_image'); ?>" alt="<?php echo $sitename.' - '.JText::_('JOFFLINE_MESSAGE'); ?>" class="img-responsive">
									<meta itemprop="image" content="<?php echo $apps->get('offline_image'); ?>">
					<?php endif; ?>
                        </p>

                        <h3><?php echo $sitename; ?></h3>
                        <h4 class="text-muted"><?php echo JText::_('JOFFLINE_MESSAGE'); ?></h4>
                        

                        <?php if ($apps->get('display_offline_message', 1) == 1 && str_replace(' ', '', $apps->get('offline_message')) != '') : ?>
							[begins tags="span" class="skills" /]<?php echo $apps->get('offline_message'); ?>[ends tags="span" /]
						<?php elseif ($apps->get('display_offline_message', 1) == 2 && str_replace(' ', '', JText::_('JOFFLINE_MESSAGE')) != '') : ?>
							[begins tags="span" class="skills" /]<?php echo JText::_('JOFFLINE_MESSAGE'); ?>[ends tags="span" /]
						<?php endif; ?>	
	                    </div>
	                </div>
	            </div>
			</div>
		</div>	
		<?php break; endswitch; ?>	

	    <footer class="footer">
	        <div class="container">
				<div class="row">
					<?php if ($this->countModules('footer1')) : ?>
					<div class="col-md-3">
			            <jdoc:include type="modules" name="footer1" style="none" />
			         </div>
					<?php endif; ?>	
					<?php if ($this->countModules('footer2')) : ?>
					<div class="col-md-3">
			            <jdoc:include type="modules" name="footer2" style="none" />
			         </div>
					<?php endif; ?>	
					<?php if ($this->countModules('footer3')) : ?>
					<div class="col-md-3">
			            <jdoc:include type="modules" name="footer3" style="none" />
			         </div>
					<?php endif; ?>	
					<?php if ($this->countModules('footer4')) : ?>
					<div class="col-md-3">
			            <jdoc:include type="modules" name="footer4" style="none" />
			         </div>
					<?php endif; ?>	
				</div>
	            <div class="pull-left">
	                WebDesigner <a href="https://www.creative-tim.com">Creative Tim</a>
	            </div>
	            <div class="copyright pull-right">
	                Copyright <span itemprop="copyrightHolder">&copy; <a href="<?php echo $this->baseurl; ?>"><?php echo $sitename; ?></a></span> - <span itemprop="copyrightYear"><?php echo date('Y'); ?></span> Toutes Droits Réservés.
	            </div>
	        </div>
	    </footer>	
	</div>
		
		<?php if ($this->countModules('referencer')) : ?>
			<jdoc:include type="modules" name="referencer" style="none" />
		<?php endif; ?>	
			[script src="<?php echo JURI::root(true).'/templates/'.$this->template.'/assets/js/material.min.js'; ?>" /] 	
		<?php if ($Params_grpsJs == 'production') : ?>
			[script src="<?php echo JURI::root(true).'/templates/'.$this->template.'/assets/js/material-kit.min.js'; ?>" /] 			
		<?php elseif ($Params_grpsJs == 'custom') : ?>	
			[script src="<?php echo JURI::root(true).'/templates/'.$this->template.'/assets/js/material-kit.js'; ?>" /]				
		<?php endif; ?>	
	
		<?php /********[ LAWS EUROPEAN - obligation show cookie legal ]*******
		[none]
		[cookies legal="echo JText::_('TPL_MATERIALKIT_COOKIESEU_HOME');" botton="Ok" url="//www.website.tld" /] 
		[/none]
			
		********[ LAWS EUROPEAN - obligation show cookie legal ]*******/ ?>
		<jdoc:include type="modules" name="debug" style="none" />


	[ends tags="body" /]  
</html>
